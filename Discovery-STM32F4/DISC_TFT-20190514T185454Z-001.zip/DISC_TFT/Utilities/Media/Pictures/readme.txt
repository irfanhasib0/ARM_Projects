This directory contains a set of image (*.bmp) and (*.jpg) files
to be used with the following projects:

- Animated
   - /Projects/STM324x9I_EVAL/Applications/Display/LTDC_AnimatedPictureFromSDCard

- BMP_128x160
   - /Projects/STM32F411RE-Nucleo/Demonstrations

- BMP_240x240
   - /Projects/STM32F412G-Discovery/Applications/Display/LCD_PicturesFromSDCard

- BMP_240x320
   - /Projects/STM32F429I-Discovery/Applications/Display/LTDC_AnimatedPictureFromUSB

- BMP_320x240 and BMP_480x272
   - /Projects/STM324x9I_EVAL/Applications/Display/LTDC_PicturesFromSDCard

- JPG
   - /Projects/STM324x9I_EVAL/Demonstrations
   - /Projects/STM324xG_EVAL/Demonstrations
   - /Projects/STM32F429I-Discovery/Applications/LibJPEG/LibJPEG_Decoding