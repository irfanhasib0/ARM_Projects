# chatter (an example for rosserial_stm32)
The basic example for rosserial_stm32

## HAL
- [STM32CubeMX](http://www.st.com/en/development-tools/stm32cubemx.html)

## Target board
- [Nucleo-F303K8(STM32F303)](http://www.st.com/en/evaluation-tools/nucleo-f303k8.html)

## Using Peripherals
- USART2 (through DMA)
- Timer2
